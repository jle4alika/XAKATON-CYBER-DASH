import { useState } from 'react'
import { postMessage } from '../services/api'

function MessageInput({ agentId, onSent }) {
  const [text, setText] = useState('')
  const [sending, setSending] = useState(false)
  const [error, setError] = useState(null)

  const handleSend = async (e) => {
    e.preventDefault()
    if (!text.trim()) return
    setSending(true)
    setError(null)
    try {
      const payload = { message: text.trim() }
      await postMessage(agentId, payload)
      setText('')
      onSent?.(payload)
    } catch (err) {
      setError(err.message || 'Failed to send message')
    } finally {
      setSending(false)
    }
  }

  return (
    <form className="stack" onSubmit={handleSend}>
      <input
        className="input"
        placeholder="Привет, агент..."
        value={text}
        onChange={(e) => setText(e.target.value)}
        aria-label="message"
      />
      <div className="flex-between">
        <button type="submit" className="btn primary" disabled={sending || !text.trim()}>
          {sending ? 'Отправка...' : 'Отправить'}
        </button>
        {error && <div className="error">{error}</div>}
      </div>
    </form>
  )
}

export default MessageInput

