import useAgentStore from '../store/agentStore'
import useEventStore from '../store/eventStore'
import useErrorStore from '../store/errorStore'

function GlobalActionsPanel() {
  const fetchAgents = useAgentStore((s) => s.fetchAgents)
  const fetchRelations = useAgentStore((s) => s.fetchRelations)
  const fetchEvents = useEventStore((s) => s.fetchEvents)
  const clearErrors = useErrorStore((s) => s.clearErrors)

  const handleReconnectWs = () => {
    window.dispatchEvent(new CustomEvent('ws:reconnect'))
  }

  return (
    <section className="panel stack">
      <div className="panel-header">
        <h3 className="panel-title">Глобальные действия</h3>
        <span className="muted">управление симуляцией</span>
      </div>
      <div className="flex" style={{ flexWrap: 'wrap' }}>
        <button className="btn" type="button" onClick={() => fetchAgents()}>Обновить агентов</button>
        <button className="btn" type="button" onClick={() => fetchRelations()}>Обновить отношения</button>
        <button className="btn" type="button" onClick={() => fetchEvents()}>Обновить события</button>
        <button className="btn" type="button" onClick={handleReconnectWs}>Переподключить WS</button>
        <button className="btn danger" type="button" onClick={clearErrors}>Очистить ошибки</button>
      </div>
    </section>
  )
}

export default GlobalActionsPanel

