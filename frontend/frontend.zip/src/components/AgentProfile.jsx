import { useMemo, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import MemoryList from './MemoryList'
import MessageInput from './MessageInput'

const moodToLabel = (mood = 0) => {
  if (mood >= 0.7) return 'happy'
  if (mood >= 0.4) return 'neutral'
  return 'upset'
}

const moodToColor = (mood = 0) => {
  if (mood >= 0.7) return 'var(--accent-green)'
  if (mood >= 0.4) return 'var(--accent-yellow)'
  return 'var(--accent-red)'
}

const tabs = [
  { id: 'memory', label: 'Память' },
  { id: 'plans', label: 'Планы' },
  { id: 'interactions', label: 'Взаимодействия' },
]

function AgentProfile({ agent }) {
  const [activeTab, setActiveTab] = useState('memory')
  const moodLabel = useMemo(() => moodToLabel(agent?.mood), [agent])

  if (!agent) {
    return <div className="empty">Агент не найден</div>
  }

  return (
    <div className="stack">
      <div className="card" style={{ borderColor: 'rgba(56, 189, 248, 0.25)' }}>
        <div className="flex-between">
          <div>
            <h2 style={{ margin: 0 }}>{agent.name}</h2>
            <div className="muted">настроение: {moodLabel}</div>
            <div className="muted">энергия: {Math.round(agent.energy ?? 0)}</div>
          </div>
          <span className="pill">
            <span className="mood-indicator" style={{ background: moodToColor(agent.mood) }} />
            {(agent.mood ?? 0).toFixed(2)}
          </span>
        </div>
      </div>

      <div>
        <div className="tabs">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              className={`tab${activeTab === tab.id ? ' active' : ''}`}
              type="button"
              onClick={() => setActiveTab(tab.id)}
            >
              {tab.label}
            </button>
          ))}
        </div>

        <div className="panel">
          <AnimatePresence mode="wait">
            {activeTab === 'memory' && (
              <motion.div
                key="memory"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -6 }}
              >
                <MemoryList memories={agent.memories || []} />
              </motion.div>
            )}
            {activeTab === 'plans' && (
              <motion.div
                key="plans"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -6 }}
                className="stack"
              >
                {(agent.plans || []).length === 0 && <div className="empty">Планов пока нет</div>}
                {(agent.plans || []).map((plan, idx) => (
                  <div key={idx} className="event-item">
                    <div>{plan.title || plan.description}</div>
                    <div className="muted">{plan.status || 'pending'}</div>
                  </div>
                ))}
              </motion.div>
            )}
            {activeTab === 'interactions' && (
              <motion.div
                key="interactions"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -6 }}
                className="stack"
              >
                {(agent.interactions || []).length === 0 && <div className="empty">Нет взаимодействий</div>}
                {(agent.interactions || []).map((item, idx) => (
                  <div key={idx} className="event-item">
                    <div>{item.description}</div>
                    <div className="muted">
                      с {item.with || item.partner || 'неизвестно'} ·{' '}
                      {item.timestamp ? new Date(item.timestamp).toLocaleString() : 'только что'}
                    </div>
                  </div>
                ))}
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      <div className="panel">
        <h3 style={{ marginTop: 0 }}>Отправить сообщение</h3>
        <MessageInput agentId={agent.id} />
      </div>
    </div>
  )
}

export default AgentProfile

