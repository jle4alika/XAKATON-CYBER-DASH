import { useEffect, useMemo, useRef, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import ForceGraph2D from 'react-force-graph-2d'

const moodToColor = (mood = 0) => {
  if (mood >= 0.7) return '#22c55e'
  if (mood >= 0.4) return '#eab308'
  return '#ef4444'
}

function RelationsGraph({ agents = [], relations = [] }) {
  const navigate = useNavigate()
  const [hoverNode, setHoverNode] = useState(null)
  const [hoverLink, setHoverLink] = useState(null)
  const fgRef = useRef(null)

  const data = useMemo(
    () => {
      const nodeMap = new Map()
      agents.forEach((a) => {
        if (!a?.id) return
        nodeMap.set(a.id, {
          id: a.id,
          name: a.name,
          mood: a.mood ?? 0.5,
          energy: a.energy ?? 50,
          activity: a.activity ?? a.energy ?? 40,
        })
      })
      relations.forEach((r) => {
        const source = r.source || r.agentA || r.from
        const target = r.target || r.agentB || r.to
        if (source && !nodeMap.has(source)) {
          nodeMap.set(source, { id: source, name: source, mood: 0.5, energy: 50, activity: 40 })
        }
        if (target && !nodeMap.has(target)) {
          nodeMap.set(target, { id: target, name: target, mood: 0.5, energy: 50, activity: 40 })
        }
      })

      const nodes = Array.from(nodeMap.values())
      const links = relations
        .filter((r) => (r.source || r.agentA || r.from) && (r.target || r.agentB || r.to))
        .map((r) => ({
          source: r.source || r.agentA || r.from,
          target: r.target || r.agentB || r.to,
          affinity: Number(r.affinity ?? r.strength ?? 0.2),
          label: r.label || r.type || 'relation',
        }))

      return { nodes, links }
    },
    [agents, relations],
  )

  useEffect(() => {
    if (!fgRef.current) return
    if (!data.nodes.length) return
    const t = setTimeout(() => {
      fgRef.current?.zoomToFit(400, 60)
    }, 150)
    return () => clearTimeout(t)
  }, [data.nodes.length, data.links.length])

  return (
    <div className="panel" style={{ position: 'relative', minHeight: 420 }}>
      <div className="panel-header">
        <h3 className="panel-title">Граф отношений</h3>
        <span className="muted">размер = активность, цвет = настроение</span>
      </div>
      {data.nodes.length === 0 ? (
        <div className="empty">Нет данных для графа</div>
      ) : (
        <ForceGraph2D
          ref={fgRef}
          height={420}
          graphData={data}
          backgroundColor="transparent"
          linkColor={(link) => (link.affinity >= 0 ? 'rgba(34,197,94,0.6)' : 'rgba(239,68,68,0.6)')}
          linkWidth={(link) => Math.max(1, Math.abs(link.affinity || 0.3) * 4)}
          onLinkHover={(link) => setHoverLink(link || null)}
          onNodeClick={(node) => navigate(`/agent/${node.id}`)}
          onNodeHover={(node) => setHoverNode(node || null)}
          nodeCanvasObject={(node, ctx, globalScale) => {
            const radius = 6 + Math.min(14, (node.activity ?? 40) / 10)
            ctx.beginPath()
            ctx.arc(node.x, node.y, radius, 0, 2 * Math.PI, false)
            ctx.fillStyle = moodToColor(node.mood)
            ctx.fill()
            ctx.strokeStyle = 'rgba(255,255,255,0.1)'
            ctx.stroke()
            const label = node.name || node.id
            const fontSize = 12 / globalScale
            ctx.font = `${fontSize}px Inter`
            ctx.fillStyle = '#e2e8f0'
            ctx.fillText(label, node.x + radius + 4, node.y + fontSize / 2)
          }}
        />
      )}
      {hoverLink && (
        <div className="tooltip" style={{ right: 12, bottom: 12 }}>
          <div style={{ fontWeight: 700 }}>
            {hoverLink.source?.name || hoverLink.source?.id} ↔ {hoverLink.target?.name || hoverLink.target?.id}
          </div>
          <div>аффинити: {hoverLink.affinity?.toFixed(2)}</div>
          <div className="muted">{hoverLink.label}</div>
        </div>
      )}
      {hoverNode && !hoverLink && (
        <div className="tooltip" style={{ right: 12, bottom: 12 }}>
          <div className="muted">Узел</div>
          <div style={{ fontWeight: 700 }}>{hoverNode.name}</div>
          <div>настроение: {hoverNode.mood.toFixed(2)}</div>
          <div>энергия: {Math.round(hoverNode.energy)}</div>
          <div>активность: {Math.round(hoverNode.activity)}</div>
        </div>
      )}
    </div>
  )
}

export default RelationsGraph

