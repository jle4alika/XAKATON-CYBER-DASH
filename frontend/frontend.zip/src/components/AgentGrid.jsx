import { useEffect } from 'react'
import useAgentStore from '../store/agentStore'
import AgentCard from './AgentCard'

function AgentGrid() {
  const agents = useAgentStore((state) => state.agents)
  const loading = useAgentStore((state) => state.loading)
  const error = useAgentStore((state) => state.error)
  const fetchAgents = useAgentStore((state) => state.fetchAgents)

  useEffect(() => {
    if (!agents.length) {
      fetchAgents()
    }
  }, [agents.length, fetchAgents])

  return (
    <div className="stack">
      {loading && <div className="status">Загрузка агентов...</div>}
      {error && <div className="error">{error}</div>}
      {!loading && !agents.length && <div className="empty">Агентов нет</div>}
      <div className="grid">
        {agents.map((agent) => (
          <AgentCard key={agent.id} agent={agent} />
        ))}
      </div>
    </div>
  )
}

export default AgentGrid

