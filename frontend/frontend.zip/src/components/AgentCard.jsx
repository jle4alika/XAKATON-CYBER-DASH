import { useMemo } from 'react'
import { useNavigate } from 'react-router-dom'

const moodToColor = (mood = 0) => {
  if (mood >= 0.7) return 'var(--accent-green)'
  if (mood >= 0.4) return 'var(--accent-yellow)'
  return 'var(--accent-red)'
}

function AgentCard({ agent }) {
  const navigate = useNavigate()
  const moodColor = useMemo(() => moodToColor(agent?.mood ?? 0.5), [agent])

  if (!agent) return null

  const goToProfile = () => navigate(`/agent/${agent.id}`)
  const handleKey = (e) => {
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault()
      goToProfile()
    }
  }

  return (
    <div
      className="card agent-card"
      onClick={goToProfile}
      onKeyDown={handleKey}
      role="button"
      tabIndex={0}
      aria-label={`Agent ${agent.name}`}
    >
      <div className="flex-between">
        <div>
          <h3 style={{ margin: 0 }}>{agent.name || 'Agent'}</h3>
          <div className="muted">ID: {agent.id}</div>
        </div>
        <span className="mood-indicator" style={{ background: moodColor }} aria-label="mood-indicator" />
      </div>

      <div className="flex" style={{ marginTop: 10, flexWrap: 'wrap' }}>
        <span className="chip">mood: {(agent.mood ?? 0).toFixed(2)}</span>
        <span className="chip">энергия: {Math.round(agent.energy ?? 0)}</span>
      </div>

      <div className="stack" style={{ marginTop: 12 }}>
        <div className="energy-bar" aria-hidden>
          <div
            className="energy-fill"
            style={{ width: `${Math.min(100, Math.max(0, agent.energy ?? 0))}%` }}
          />
        </div>
        <div className="muted" style={{ fontSize: 13 }}>
          {agent.status || agent.currentTask || 'Готов к действию'}
        </div>
      </div>
    </div>
  )
}

export default AgentCard

