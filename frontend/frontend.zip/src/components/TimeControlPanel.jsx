import useSimulationStore from '../store/simulationStore'

function TimeControlPanel() {
  const speed = useSimulationStore((state) => state.speed)
  const isPaused = useSimulationStore((state) => state.isPaused)
  const status = useSimulationStore((state) => state.status)
  const updating = useSimulationStore((state) => state.updating)
  const setSpeed = useSimulationStore((state) => state.setSpeed)
  const pause = useSimulationStore((state) => state.pause)
  const resume = useSimulationStore((state) => state.resume)

  return (
    <section className="panel stack">
      <div className="panel-header">
        <h3 className="panel-title">Панель времени</h3>
        <span className="muted">Скорость: {speed.toFixed(1)}x</span>
      </div>
      <div className="stack">
        <input
          type="range"
          min="0.5"
          max="5"
          step="0.5"
          value={speed}
          onChange={(e) => setSpeed(Number(e.target.value))}
          aria-label="speed"
        />
        <div className="flex">
          <button className="btn danger" onClick={pause} disabled={isPaused || updating}>
            Пауза
          </button>
          <button className="btn primary" onClick={resume} disabled={!isPaused || updating}>
            Продолжить
          </button>
        </div>
        <div className="muted">{status || (isPaused ? 'На паузе' : 'Идёт симуляция')}</div>
      </div>
    </section>
  )
}

export default TimeControlPanel

