function MemoryList({ memories }) {
  if (!memories || memories.length === 0) {
    return <div className="empty">Воспоминаний пока нет</div>
  }

  return (
    <div className="stack">
      {memories.map((memory, idx) => (
        <div key={memory.id || idx} className="event-item">
          <div>{memory.description || memory.text}</div>
          <div className="muted">
            эмоция: {memory.emotion || 'нейтрально'} ·{' '}
            {memory.timestamp ? new Date(memory.timestamp).toLocaleString() : 'недавно'}
          </div>
        </div>
      ))}
    </div>
  )
}

export default MemoryList

