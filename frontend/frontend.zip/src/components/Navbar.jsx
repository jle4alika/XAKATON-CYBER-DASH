import { NavLink } from 'react-router-dom'

const links = [
  { to: '/', label: 'Дашборд' },
  { to: '/relations', label: 'Отношения' },
  { to: '/settings', label: 'Настройки' },
]

function Navbar() {
  return (
    <header className="navbar">
      <div className="navbar-inner">
        <div className="brand">
          <span className="logo-dot" />
          <span>КИБЕР РЫВОК · Агенты</span>
        </div>
        <nav className="nav-links">
          {links.map((link) => (
            <NavLink
              key={link.to}
              to={link.to}
              className={({ isActive }) => `nav-link${isActive ? ' active' : ''}`}
              end={link.to === '/'}
            >
              {link.label}
            </NavLink>
          ))}
        </nav>
      </div>
    </header>
  )
}

export default Navbar

