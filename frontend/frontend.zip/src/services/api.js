import useErrorStore from '../store/errorStore'

const API_BASE = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8000'

const buildUrl = (path) => `${API_BASE}${path}`

async function request(path, options = {}) {
  const headers = {
    'Content-Type': 'application/json',
    ...(options.headers || {}),
  }

  try {
    const res = await fetch(buildUrl(path), { ...options, headers })
    const contentType = res.headers.get('content-type') || ''
    const isJson = contentType.includes('application/json')
    const data = isJson ? await res.json().catch(() => null) : await res.text()

    if (!res.ok) {
      const message = (data && data.detail) || res.statusText || 'Request failed'
      useErrorStore.getState().pushError({ source: path, message, context: { status: res.status, data } })
      throw new Error(message)
    }

    return data
  } catch (err) {
    useErrorStore.getState().pushError({
      source: path,
      message: err.message || 'Request failed',
      context: { options },
    })
    throw err
  }
}

export const getAgents = () => request('/api/agents')
export const getAgent = (id) => request(`/api/agents/${id}`)
export const getRelations = () => request('/api/relations')
export const getEvents = () => request('/api/events')
export const postEvent = (payload) =>
  request('/api/events', { method: 'POST', body: JSON.stringify(payload) })
export const postMessage = (id, payload) =>
  request(`/api/agents/${id}/message`, { method: 'POST', body: JSON.stringify(payload) })
export const postSimulationControl = (payload) =>
  request('/api/simulation/control', { method: 'POST', body: JSON.stringify(payload) })

export { API_BASE }

