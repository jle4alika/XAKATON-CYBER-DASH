import { create } from 'zustand'
import { getEvents } from '../services/api'

const MAX_EVENTS = 200

const fallbackEvents = [
  { id: 'e1', description: 'Alice greeted Bob', timestamp: new Date().toISOString() },
  { id: 'e2', description: 'Bob responded positively', timestamp: new Date().toISOString() },
  { id: 'e3', description: 'Eve insulted Alice', timestamp: new Date().toISOString() },
]

const useEventStore = create((set) => ({
  events: [],
  loading: false,
  error: null,
  fetchEvents: async () => {
    set({ loading: true, error: null })
    try {
      const data = await getEvents()
      set({ events: Array.isArray(data) ? data.slice(-MAX_EVENTS) : [] })
    } catch (err) {
      console.warn('Falling back to mock events', err)
      set({ events: fallbackEvents, error: 'Оффлайн режим: мок-события' })
    } finally {
      set({ loading: false })
    }
  },
  addEvent: (event) =>
    set((state) => {
      const next = [...state.events, event].slice(-MAX_EVENTS)
      return { events: next }
    }),
}))

export default useEventStore

