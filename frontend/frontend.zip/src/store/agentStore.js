import { create } from 'zustand'
import { getAgent, getAgents, getRelations } from '../services/api'

const fallbackAgents = [
  {
    id: 'alice',
    name: 'Alice',
    mood: 0.82,
    energy: 78,
    memories: [
      { description: 'Met Bob', emotion: 'positive', timestamp: new Date().toISOString() },
      { description: 'Was insulted by Eve', emotion: 'negative', timestamp: new Date().toISOString() },
    ],
    plans: [{ title: 'Explore the plaza', status: 'active' }],
    interactions: [{ with: 'Bob', description: 'Chatted about treasure', timestamp: new Date().toISOString() }],
  },
  {
    id: 'bob',
    name: 'Bob',
    mood: 0.55,
    energy: 64,
    memories: [{ description: 'Replied to Alice happily', emotion: 'positive', timestamp: new Date().toISOString() }],
    plans: [{ title: 'Guard the camp', status: 'planned' }],
    interactions: [],
  },
  {
    id: 'eve',
    name: 'Eve',
    mood: 0.2,
    energy: 42,
    memories: [{ description: 'Insulted Alice', emotion: 'negative', timestamp: new Date().toISOString() }],
    plans: [{ title: 'Collect intel', status: 'in-progress' }],
    interactions: [],
  },
]

const fallbackRelations = [
  { source: 'alice', target: 'bob', affinity: 0.78 },
  { source: 'bob', target: 'eve', affinity: -0.45 },
  { source: 'alice', target: 'eve', affinity: -0.62 },
]

const useAgentStore = create((set, get) => ({
  agents: [],
  relations: [],
  selectedAgent: null,
  loading: false,
  error: null,
  fetchAgents: async () => {
    set({ loading: true, error: null })
    try {
      const data = await getAgents()
      set({ agents: data || [] })
    } catch (err) {
      console.warn('Falling back to mock agents', err)
      set({ agents: fallbackAgents, error: 'Оффлайн режим: мок-агенты' })
    } finally {
      set({ loading: false })
    }
  },
  fetchAgentById: async (id) => {
    set({ loading: true, error: null })
    try {
      const data = await getAgent(id)
      set({ selectedAgent: data })
    } catch (err) {
      const local = get().agents.find((a) => `${a.id}` === `${id}`) || fallbackAgents.find((a) => `${a.id}` === `${id}`)
      set({ selectedAgent: local || null, error: err.message || 'Failed to load agent' })
    } finally {
      set({ loading: false })
    }
  },
  fetchRelations: async () => {
    set({ loading: true, error: null })
    try {
      const data = await getRelations()
      set({ relations: data || [] })
    } catch (err) {
      console.warn('Falling back to mock relations', err)
      set({ relations: fallbackRelations, error: 'Оффлайн режим: мок-отношения' })
    } finally {
      set({ loading: false })
    }
  },
  updateAgentFromEvent: (partial) => {
    if (!partial?.id) return
    set((state) => {
      const agents = state.agents.map((agent) => (agent.id === partial.id ? { ...agent, ...partial } : agent))
      const selectedAgent =
        state.selectedAgent && state.selectedAgent.id === partial.id
          ? { ...state.selectedAgent, ...partial }
          : state.selectedAgent
      return { agents, selectedAgent }
    })
  },
  setRelations: (relations) => set({ relations: relations || [] }),
}))

export default useAgentStore

