import { useEffect } from 'react'
import RelationsGraph from '../components/RelationsGraph'
import useAgentStore from '../store/agentStore'

function RelationsPage() {
  const agents = useAgentStore((state) => state.agents)
  const relations = useAgentStore((state) => state.relations)
  const loading = useAgentStore((state) => state.loading)
  const error = useAgentStore((state) => state.error)
  const fetchAgents = useAgentStore((state) => state.fetchAgents)
  const fetchRelations = useAgentStore((state) => state.fetchRelations)

  useEffect(() => {
    if (!agents.length) {
      fetchAgents()
    }
    fetchRelations()
  }, [agents.length, fetchAgents, fetchRelations])

  return (
    <div className="stack">
      <section>
        <div className="section-title">
          <h2>Граф отношений</h2>
          <span className="muted">наведите на связь, чтобы увидеть аффинити</span>
        </div>
        {loading && <div className="status">Загрузка...</div>}
        {error && <div className="error">{error}</div>}
        <RelationsGraph agents={agents} relations={relations} />
      </section>
    </div>
  )
}

export default RelationsPage

