import { useState } from 'react'
import AgentGrid from '../components/AgentGrid'
import EventStream from '../components/EventStream'
import TimeControlPanel from '../components/TimeControlPanel'
import GlobalActionsPanel from '../components/GlobalActionsPanel'
import useEventStore from '../store/eventStore'
import { postEvent } from '../services/api'

function DashboardPage() {
  const [text, setText] = useState('')
  const [saving, setSaving] = useState(false)
  const addEvent = useEventStore((state) => state.addEvent)

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (!text.trim()) return
    setSaving(true)
    try {
      const payload = await postEvent({ description: text.trim() })
      addEvent(
        payload || {
          id: `local-${Date.now()}`,
          description: text.trim(),
          timestamp: new Date().toISOString(),
        },
      )
      setText('')
    } catch (err) {
      addEvent({
        id: `local-${Date.now()}`,
        description: text.trim(),
        timestamp: new Date().toISOString(),
      })
      console.warn('Fallback add event', err)
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="stack">
      <section className="panel">
        <div className="panel-header">
          <h2 className="panel-title">Жизнь агентов</h2>
          <span className="muted">Онлайн-симуляция</span>
        </div>
        <AgentGrid />
      </section>

      <div className="row">
        <EventStream />
        <TimeControlPanel />
      </div>

      <GlobalActionsPanel />

      <section className="panel">
        <div className="panel-header">
          <h3 className="panel-title">Добавить событие</h3>
        </div>
        <form className="flex" onSubmit={handleSubmit}>
          <input
            className="input"
            placeholder="Напр. «Алиса поприветствовала Боба»"
            value={text}
            onChange={(e) => setText(e.target.value)}
          />
          <button className="btn primary" type="submit" disabled={!text.trim() || saving}>
            {saving ? 'Отправка...' : 'Добавить'}
          </button>
        </form>
      </section>
    </div>
  )
}

export default DashboardPage

