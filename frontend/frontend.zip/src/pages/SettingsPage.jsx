import useErrorStore from '../store/errorStore'

function SettingsPage() {
  const errors = useErrorStore((s) => s.errors)
  const clearErrors = useErrorStore((s) => s.clearErrors)

  return (
    <div className="stack">
      <div className="section-title">
        <h2>Настройки и диагностика</h2>
        <button className="btn" type="button" onClick={clearErrors}>
          Очистить ошибки
        </button>
      </div>
      <div className="panel stack">
        <h3 style={{ margin: 0 }}>Ошибки API/WS</h3>
        {errors.length === 0 && <div className="empty">Ошибок нет</div>}
        {errors.map((err) => (
          <div key={err.id} className="event-item">
            <div className="flex-between">
              <div className="muted">{new Date(err.timestamp).toLocaleString()}</div>
              <span className="badge">{err.source}</span>
            </div>
            <div>{err.message}</div>
            {err.context && <div className="muted">{JSON.stringify(err.context)}</div>}
          </div>
        ))}
      </div>
    </div>
  )
}

export default SettingsPage

